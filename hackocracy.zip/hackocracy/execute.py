import setup as s
import sys
from sys import version
print(version)
arg1= sys.argv[1]
print(s.sentiment(arg1))
